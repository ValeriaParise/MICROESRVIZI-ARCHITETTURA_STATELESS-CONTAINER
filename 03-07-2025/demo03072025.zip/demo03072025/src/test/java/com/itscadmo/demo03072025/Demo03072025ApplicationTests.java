package com.itscadmo.demo03072025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo03072025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
