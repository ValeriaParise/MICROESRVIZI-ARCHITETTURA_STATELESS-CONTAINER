package com.itscadmo.demo03072025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo03072025Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo03072025Application.class, args);
	}

}
